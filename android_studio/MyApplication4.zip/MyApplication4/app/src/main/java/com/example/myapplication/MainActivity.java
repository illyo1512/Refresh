package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Native 함수 연결 (사용 중인 경우 유지)
    public native String stringFromJNI();

    static {
        System.loadLibrary("native-lib");
    }

    // 알람 상세 토글 상태
    private boolean isExpanded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // alarm_view.xml 동적 로딩
        LayoutInflater inflater = LayoutInflater.from(this);
        View alarmView = inflater.inflate(R.layout.alarm_view, null);

        // 각 UI 요소 찾기
        TextView title = alarmView.findViewById(R.id.alarm_title);
        TextView shortInfo = alarmView.findViewById(R.id.alarm_short);
        TextView detail = alarmView.findViewById(R.id.alarm_detail);
        ImageButton btnClose = alarmView.findViewById(R.id.btn_close);
        ImageButton btnToggle = alarmView.findViewById(R.id.btn_toggle);

        // 텍스트 설정
        title.setText("위험지역에 접근했습니다!");
        shortInfo.setText("범죄유형: 폭행\n위험도: 높음\n범위: 150m 이내");
        detail.setText("이 지역은 최근 폭행 사건이 다수 발생한 구역입니다. 가능한 한 다른 경로로 이동하세요.");

        // X 버튼 클릭 시 알림 뷰 숨김
        btnClose.setOnClickListener(v -> alarmView.setVisibility(View.GONE));

        // 아래/위 버튼 클릭 시 상세 정보 토글 + 아이콘 전환
        btnToggle.setOnClickListener(v -> {
            if (isExpanded) {
                detail.setVisibility(View.GONE);
                btnToggle.setImageResource(android.R.drawable.arrow_down_float);
                isExpanded = false;
            } else {
                detail.setVisibility(View.VISIBLE);
                btnToggle.setImageResource(android.R.drawable.arrow_up_float);
                isExpanded = true;
            }
        });

        // 알람 뷰를 화면 상단에 추가
        FrameLayout rootLayout = findViewById(android.R.id.content);
        rootLayout.addView(alarmView);
    }
}
